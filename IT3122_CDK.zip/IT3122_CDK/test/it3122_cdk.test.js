// const cdk = require('aws-cdk-lib');
// const { Template } = require('aws-cdk-lib/assertions');
// const It3122Cdk = require('../lib/it3122_cdk-stack');

// example test. To run these tests, uncomment this file along with the
// example resource in lib/it3122_cdk-stack.js
test('SQS Queue Created', () => {
//   const app = new cdk.App();
//   // WHEN
//   const stack = new It3122Cdk.It3122CdkStack(app, 'MyTestStack');
//   // THEN
//   const template = Template.fromStack(stack);

//   template.hasResourceProperties('AWS::SQS::Queue', {
//     VisibilityTimeout: 300
//   });
});
